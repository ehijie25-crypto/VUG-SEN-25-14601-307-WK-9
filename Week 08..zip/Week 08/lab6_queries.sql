-- VERITAS UNIVERSITY, ABUJA
-- DEPARTMENT OF SOFTWARE ENGINEERING
-- VUA-SEN307 Database Systems
-- Week 8 Practical Lab 6: Aggregate Functions, Grouping and Subqueries
-- Student: Mishael Ehi-Charles
--
-- NOTE:
-- This script uses the sample sen307 database created during this guided lab.
-- It assumes the Department, Student, Course and Enrolment tables already exist
-- and contain the sample records used for Tasks 1-5.

USE sen307;

-- =========================================================
-- TASK 1: Count students enrolled in each course,
-- including courses with zero students.
-- LEFT JOIN keeps every course; COUNT(e.student_id) ignores NULL.
-- =========================================================

SELECT
    c.course_title,
    COUNT(e.student_id) AS total_students
FROM Course c
LEFT JOIN Enrolment e
    ON c.course_id = e.course_id
GROUP BY c.course_id, c.course_title
ORDER BY total_students DESC;


-- =========================================================
-- TASK 2: Find courses with more than a given number
-- of students, using HAVING.
-- Run each query separately to test thresholds 3, 5 and 7.
-- =========================================================

-- Task 2a: More than 3 students
SELECT
    c.course_title,
    COUNT(e.student_id) AS total_students
FROM Course c
LEFT JOIN Enrolment e
    ON c.course_id = e.course_id
GROUP BY c.course_id, c.course_title
HAVING COUNT(e.student_id) > 3
ORDER BY total_students DESC;

-- Task 2b: More than 5 students
SELECT
    c.course_title,
    COUNT(e.student_id) AS total_students
FROM Course c
LEFT JOIN Enrolment e
    ON c.course_id = e.course_id
GROUP BY c.course_id, c.course_title
HAVING COUNT(e.student_id) > 5
ORDER BY total_students DESC;

-- Task 2c: More than 7 students
SELECT
    c.course_title,
    COUNT(e.student_id) AS total_students
FROM Course c
LEFT JOIN Enrolment e
    ON c.course_id = e.course_id
GROUP BY c.course_id, c.course_title
HAVING COUNT(e.student_id) > 7
ORDER BY total_students DESC;


-- =========================================================
-- TASK 3: Calculate the average number of courses taken
-- per student, including students with zero courses.
-- The inner query counts courses for each student.
-- The outer query calculates the average of those counts.
-- =========================================================

-- First, show the number of courses taken by each student
SELECT
    s.student_id,
    s.full_name,
    COUNT(e.course_id) AS course_count
FROM Student s
LEFT JOIN Enrolment e
    ON s.student_id = e.student_id
GROUP BY s.student_id, s.full_name
ORDER BY s.student_id;

-- Then, calculate the average course count
SELECT
    ROUND(AVG(course_count), 2) AS average_courses
FROM (
    SELECT
        s.student_id,
        COUNT(e.course_id) AS course_count
    FROM Student s
    LEFT JOIN Enrolment e
        ON s.student_id = e.student_id
    GROUP BY s.student_id
) AS per_student;


-- =========================================================
-- TASK 4: Find students who are not enrolled in any course.
-- This is a non-correlated subquery: the inner query gets
-- the student IDs found in Enrolment.
-- =========================================================

SELECT
    student_id,
    full_name
FROM Student
WHERE student_id NOT IN (
    SELECT student_id
    FROM Enrolment
);


-- =========================================================
-- TASK 5: For each department, find the student(s) with
-- the highest number of enrolments. Ties are allowed.
-- The subqueries refer to the outer query's s.dept_id
-- and s.student_id, making this a correlated subquery.
-- =========================================================

SELECT
    d.dept_name,
    s.full_name,
    (
        SELECT COUNT(*)
        FROM Enrolment e
        WHERE e.student_id = s.student_id
    ) AS courses
FROM Student s
JOIN Department d
    ON s.dept_id = d.dept_id
WHERE (
    SELECT COUNT(*)
    FROM Enrolment e
    WHERE e.student_id = s.student_id
) = (
    SELECT MAX(
        (
            SELECT COUNT(*)
            FROM Enrolment e2
            WHERE e2.student_id = s2.student_id
        )
    )
    FROM Student s2
    WHERE s2.dept_id = s.dept_id
)
ORDER BY d.dept_name;
